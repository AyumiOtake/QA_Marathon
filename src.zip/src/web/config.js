const config = {
  apiUrl: 'http://localhost:13519'
};

export default config;