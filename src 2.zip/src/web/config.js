const config = {
  apiUrl: '/api_ayumi_otake'
};

export default config;